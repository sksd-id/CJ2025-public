# CJ Flag Validator

## Prerequisites

- [NW.js](https://nwjs.io/) (Version 0.99.0)

## How to Run

### Using NPM

1.  Install dependencies:
    ```bash
    npm install
    ```
2.  Run the application:
    ```bash
    npm start
    ```